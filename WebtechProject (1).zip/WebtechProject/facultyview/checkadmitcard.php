<?php
require_once '../facultycontrol/logincheck.php' ;
$admit="0192345";

?>
