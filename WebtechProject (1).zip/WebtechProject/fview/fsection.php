<<!DOCTYPE html>
<html>
<head>
<title> Faculty Section information Page  </title>
</head> 
 <body>
    <h1 align="center"> Faculty  information Page   </h1>
   
  
    <h1> <h1 align="center"> Section info  </h1> 
    <br/>

</body> 

</html>