<!DOCTYPE html>
<html>
<head>
<title> Faculty Home Page  </title>
</head> 
 <body>
    <h1 align="center">AIUB Portal</h1>
   
  
    <h1> <h1 align="center">Hello Faculty Welcome to AIUB Portal </h1> 
    <br/>


     



<br/>
    
        <table border = "10" align="center" >

             <tr>
                <td> <h5>   <a href="ffaculty.php">Faculty Information</a>  </h5> </td>
            </tr>

            <tr>
                <td> <h5>  <a href="fstudent.php">Student Information</a>  </h5> </td>
            </tr> 

            <tr>
                <td> <h5>  <a href="fcourses.php">Courses Information</a>  </h5> </td>
            </tr> 
            <tr>
                <td> <h5>  <a href="fnotice.php">Notice Information</a>  </h5> </td>
            </tr> 

            <tr>
                <td> <h5>  <a href="fresults.php">Update Results Information</a>  </h5> </td>
            </tr> 

            <tr>
                <td> <h5>  <a href="fsection.php">Section Information</a>  </h5> </td>
            </tr> 
 
       
        </table>
    
</body> 

</html>