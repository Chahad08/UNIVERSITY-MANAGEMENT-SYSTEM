<<!DOCTYPE html>
<html>
<head>
<title> Faculty update result Page  </title>
</head> 
 <body>
    <h1 align="center"> Faculty update result Page  </h1>
   
  
    <h1> <h1 align="center"> update result  </h1> 
    <br/>

</body> 

</html>