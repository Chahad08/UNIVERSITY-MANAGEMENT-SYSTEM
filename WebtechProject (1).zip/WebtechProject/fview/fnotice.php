<!DOCTYPE html>
<html>
<head>
<title> Faculty Home Page  </title>
</head> 
 <body>
    <h1 align="center">AIUB Portal</h1>
   
  
    <h1> <h1 align="center">Hello Faculty Welcome to AIUB Portal </h1> 
    <br/>


     



<br/>
    
        <table border = "10" align="center">

             <tr>
                <td> <h5>   <a href="ffaculty.php">Faculty Information</a>  </h5> </td>
            </tr>
        </table>
        <table border = "10" align="center" >

             <tr>
                <td> <h5>   <a href="ffaculty.php">Faculty Information</a>  </h5> </td>
            </tr>
        </table>
        <table border = "10" align="center">

             <tr>
                <td> <h5>   <a href="ffaculty.php">Faculty Information</a>  </h5> </td>
            </tr>
        </table>
        <table border = "10" align="center" >

             <tr>
                <td> <h5>   <a href="ffaculty.php">Faculty Information</a>  </h5> </td>
            </tr>
        </table>



            
    
</body> 

</html>