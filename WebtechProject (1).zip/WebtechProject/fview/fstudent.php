<<!DOCTYPE html>
<html>
<head>
<title> Faculty,student information Page  </title>
</head> 
 <body>
    <h1 align="center"> student information Page for Faculty  </h1>
   
  
    <h1> <h1 align="center"> student info  </h1> 
    <br/>

</body> 

</html>