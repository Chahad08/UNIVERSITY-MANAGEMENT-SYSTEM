<<!DOCTYPE html>
<html>
<head>
<title> Faculty information Page  </title>
</head> 
 <body>

    <h1 align="center"> Faculty  information Page </h1>
   
  
    <h1> <h1 align="center"> Welcome Faculty  </h1> 
    <br/>

</body> 

</html>