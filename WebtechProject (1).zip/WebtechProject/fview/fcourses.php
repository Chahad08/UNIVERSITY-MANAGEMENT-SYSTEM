<<!DOCTYPE html>
<html>
<head>
<title> Faculty course information Page  </title>
</head> 
 <body>
    <h1 align="center"> Faculty course information Page </h1>
   
  
    <h1> <h1 align="center"> course information  </h1> 
    <br/>

</body> 

</html>