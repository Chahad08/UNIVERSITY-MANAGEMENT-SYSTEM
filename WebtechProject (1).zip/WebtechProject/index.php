<?php

header("location: view/HomePage.php");
?>