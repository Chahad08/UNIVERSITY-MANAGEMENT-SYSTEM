<html>
<body>
<link rel="stylesheet" type="text/css" href="../css/mycss13.css">
<h1>Overview of American International University-Bangladesh (AIUB)<h1>
<h4>American International University - Bangladesh (AIUB) is a government approved private university founded in 1994 by Dr. Anwarul Abedin. The university is an independent organization with its own Board of Trustees.</h4>
<h1>Vision<h1>

<h4>AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH (AIUB) envisions promoting professionals and excellent leadership catering to the technological progress and development needs of the country.</h4>

<h1>Mission<h1>
<h4>AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH (AIUB) is committed to provide quality and excellent computer-based academic programs responsive to the emerging challenges of the time. It is dedicated to nurture and produce competent world class professional imbued with strong sense of ethical values ready to face the competitive world of arts, business, science, social science and technology.</h4>
<h1>Quality Policy<h1>
<h4>Quality shall be adhered to in conformity with the prescribed national and international standards of quality and excellence including those provided by the professional bodies and organizations. The American International University- Bangladesh is committed to translate into actions the programs, projects and activities related to the sustainable delivery of quality management operation system. The students being the valued customers are the central focus of the university shall be provided with utmost care and attention to meet their primordial needs and future career success. In view of this commitment, the university shall exert best efforts to harmonize its action through collaboration, cooperation and consultation with every unit and components of the university.

</h4>
<h1>Goals<h1>
<h4>Sustain development and progress of the university
Continue to upgrade educational services and facilities responsive of the demands for change and needs of the society
Inculcate professional culture among management, faculty and personnel in the attainment of the institution's vision, mission and goals
Enhance research consciousness in discovering new dimensions for curriculum development and enrichment
Implement meaningful and relevant community outreach programs reflective of the available resources and expertise of the university
Establish strong networking of programs, sharing of resources and expertise with local and international educational institutions and organizations
Accelerate the participation of alumni, students and professionals in the implementation of educational programs and development of projects designed to expand and improve global academic standards</h4>
<h1>Linkages and Networking<h1>
<h4>Microsoft Security Cooperation Program (SCP)
Microsoft IT Academy (ice.aiub.edu)
MSDNAA (ice.aiub.edu)
CCNA and IT Essentials in collaboration with CISCO (ice.aiub.edu)
Authorized Sun Education Centre (ice.aiub.edu)
Education Partner of Bangladesh Cricket Board (ice.aiub.edu)
Oracle Academy (ice.aiub.edu)
Certifies Internet Web (CIW) Professional Program (ice.aiub.edu)
CTP Authorized Training Academy (ice.aiub.edu)
The Duke of Edinburgh's International Award (www.intaward.org)</h4>

<h1>Member:<h1>
<h4>American Chamber of Commerce in Bangladesh (AmCham)
Association of Management Development Institutions of Bangladesh (AMDIB)</h4>
</body>
</html>