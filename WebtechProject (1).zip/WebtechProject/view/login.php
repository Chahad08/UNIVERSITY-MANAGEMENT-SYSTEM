<!DOCTYPE HTML>
<html>  
<head>
<title>login</title>
<link rel="stylesheet" type="text/css" href="../css/mycss6.css">
</head>
<h1 align='center'>WELCOME TO AIUB PORTAL</h1>
<h2 align="center">What type of user are you!</h2>

<button><a href="../adminview/adlogin.php">  Admin </button>

&nbsp;  &nbsp;---------- &nbsp;  &nbsp;

<button><a href="../facultyview/faclogin.php">  Faculty </button>

&nbsp;  &nbsp;---------- &nbsp;  &nbsp;

<button><a href="../studentview/stulogin.php">  Student </button>
<br>
<br>

<button><a href="HomePage.php">Go To HomePage </button>
</tr>
<tr>
</tr></b>
</table>
</html>