<!DOCTYPE html>
<html>

<title>Contact us</title>
<link rel="stylesheet" type="text/css" href="../css/mycss8.css">
</head>
<body>

<table align="left" cellpadding = "10" border="1" class="content-table">
<center><h1><th >Contact </th><h1></center>
<tr>
<td> ADDRESS: </td>
<td>408/1, Kuratoli, Khilkhet, Dhaka 1229, Bangladesh</td>
</tr>

<align="left">





<tr>
<td> Telephone: </td>
<td>+88 02 841 4046-9; +88 02 841 4050
</td>
</tr>
<tr>
<td> Fax: </td>
<td>+88 02 841 2255
</td>
</tr>



<tr>
<td> Email: <br /><br /><br /> </td>
<td>info@aiub.edu</td>
</tr>
<tr>
<td> Web: </td>
<td>	
www.aiub.edu
</td>
</tr>
<tr>
<td> Facebook: </td>
<td>	
www.facebook.com/aiub.edu
</td>
</tr>

</body>
</html>



<html>


<body>


<table align="center" cellpadding = "10" border="1" class="content-table">
<center><h2><th >Admission information </th></h2></center>
<tr>
<td> Mobile:: </td>
<td>+880 18 4411 5000

+880 18 8656 6666</td>
</tr>

<align="right">




</td>
</tr>
<tr>
<td> Telephone: </td>
<td>+88 02 841 4046-9;

+88 02 841 4050;

Ext.: 201, 202
</td>
</tr>
<tr>
<td> Graduate Programs

[12pm to 8pm]: </td>
<td>+880 18 4411 5010

+88 02 841 4046-9

Ext. 332
</td>
</tr>



</body>
</html>
