<!DOCTYPE HTML>
<html>
<head>
<title>Aiub portal</title>
</head>
<link rel="stylesheet" type="text/css" href="../css/mycss2.css">
<body>

<div class="header"></div>



  


<div class="sticky">
  <div class="topnav">

<a href="ContactUs.php">Contact Us</a>
<a href="ApplyNow.php">Apply</a>
<a  href="login.php">Login</a>
<a href="notice.php">Notice</a>


<h1><a href="#">Americal International University-Bangladesh<br>-Where leaders are created</a></h1<br>
  
  
<img src="logo.jpg" width="50" height="50" title="Logo of a company" alt="Logo of a company" />
  
  </div>
</div>
</div>

<div class="marquee">
<marquee direction="left" behavior="alternate"  bgcolor="white">

<img src="../download/(5).jpg" height="600px" width="500px"><img src="../download/(6).jpg" height="600px" width="500px"><img src="../download/(3).jpg" height="600px" width="500px"><img src="../download/(4).jpg" height="600px" width="500px">
</marquee>
</div>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="footer">
<h3 align="left">American International University-Bangladesh (AIUB)<br>
 408/1, Kuratoli, Khilkhet,<br>
Dhaka 1229, Bangladesh<br>
 info@aiub.edu </h3>
 <div class="navbar">
 <tr><td> <h5><a href="aboutus.php">About Us</a><br></a></h5> </td>
</div>
</div>

</body>
</html>




