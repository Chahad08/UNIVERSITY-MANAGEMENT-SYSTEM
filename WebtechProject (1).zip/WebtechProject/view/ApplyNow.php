<!DOCTYPE HTML>
<html>  
<head>
<link rel="stylesheet" type="text/css" href="../css/mycss11.css">
<title>Applying</title>
</head>
<h1 align='center'>Choose program type</h1>
<table align='center'>
<tr>
<td><b><a href="Undergraduation.php">Undergraduation</b>
</td></tr>
<tr>
<td><b><a href="Graduation.php">Graduation</b>
</td>
</tr></b>
</table>
</html>